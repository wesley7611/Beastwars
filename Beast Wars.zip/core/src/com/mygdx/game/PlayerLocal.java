/**
* PlayerLocal is the player's main player class. Handles player turn based on user input
* and allows for user control against AI or network opponent.
* 
*
* @author  Philip Wesley
* @version 1.0
* @since   2016-11-25 
*/
package com.mygdx.game;

import cards.*;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

public class PlayerLocal extends Player {
	
int selectedItemInt;
LargeDisplay large;

	public PlayerLocal(String name, Stage stage) {
		super(name);
		fy = 180;
		meterx=0;
		large = new LargeDisplay();
		large.positionChanged();
		stage.addActor(large);
		// TODO Auto-generated constructor stub
	}

	/**
	 * takeTurn handles user input and enables user interaction to carry out their turn
	 */
	public boolean takeTurn(Player enemy) {

		// Checks for input on card in hand
		for (int i = 0; i < hand.handSize(); i++) {
			if (hand.returnCard(i).isPressed()) {
				large.setVisible(false);
				if (hand.returnCard(i).isActor())
					playFromHand(i);
				else if (hand.returnCard(i).isItem()){
					if (selectedItem==hand.returnCard(i)){
						this.selectedItem=null;
						
						hand.returnCard(i).addAction(Actions.moveTo(hand.returnCard(i).getX(), hand.returnCard(i).getY()-10, (float) 0.1));
						//hand.returnCard(i);
					}
					else{
						if(selectedItem!=null){
							selectedItem.addAction(Actions.moveTo(selectedItem.getX(), selectedItem.getY()-10, (float) 0.1));
							
						}
						this.selectedItem = (ItemCard) hand.returnCard(i);
						hand.returnCard(i).addAction(Actions.moveTo(hand.returnCard(i).getX(), hand.returnCard(i).getY()+10, (float) 0.1));
						selectedItemInt=i;
					}
					
				}
					
			}
			if(hand.returnCard(i).isHovered()){
				large.toFront();
				large.sprite.setTexture(hand.returnCard(i).returnFront());
				//large.setSprite();
				large.setVisible(true);
			}
		}

		for (int i = 0; i < field.getFieldSize(); i++) {
			if (field.returnCard(i).isPressed()) {
				if (selectedItem != null) {
					selectedItem.ItemUse(this, i);
					selectedItem.addAction(Actions.moveTo(1400, 800, 1));
					selectedItem = null;
					hand.removeCard(selectedItemInt);
					hand.reallignHand();
				} else if(selectedActor== field.returnCard(i)){
					//selectedActor.flipBack();
					//large.setVisible(true);
					//selectedActor.addAction(Actions.moveTo(selectedActor.getX(), selectedActor.getY()-10, (float) 0.1));
					//this.selectedActor = null;
					
				}
				else {
				this.selectedActor = field.returnCard(i);
				field.returnCard(i).addAction(Actions.moveTo(field.returnCard(i).getX(), field.returnCard(i).getY()+10, (float) 0.1));
				}
			}

		}

		// checks for inputon cards in enemt field
		for (int i = 0; i < enemy.field.getFieldSize(); i++) {
			if (enemy.field.returnCard(i).isPressed() && selectedActor != null && AP>= selectedActor.returnAttackCost()) {
				float endX;
				float endY;
				endX = selectedActor.getX();
				endY = selectedActor.getY()-10;
				selectedActor.addAction(Actions.sequence(Actions.moveTo(enemy.field.returnCard(i).getX(), enemy.field.returnCard(i).getY()-20, (float) 0.1), Actions.moveTo(endX, endY, (float) 0.1)));
				AP = AP - selectedActor.attack(enemy.field.returnCard(i));
				refreshAP();
				selectedActor = null;
			}
		}


		// checks to see if enter hit to end turn
		if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {

			if (!field.isFieldEmpty()){
				replenishAP();
				return true;
			}
		}
		return false;
	}
}
