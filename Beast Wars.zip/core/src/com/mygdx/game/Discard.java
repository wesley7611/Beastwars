/**
* Discard class is to be used as a pile for discarded cards. unused at this point.
* 
*
* @author  Philip Wesley
* @version 1.0
* @since   2016-11-25 
*/
package com.mygdx.game;
public class Discard {
	//to be done
}
