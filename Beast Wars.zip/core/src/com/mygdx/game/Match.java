/**
* Match class is responsible for managing the individual matches played by the PC.
* 
*
* @author  Philip Wesley
* @version 1.0
* @since   2016-11-25 
*/
package com.mygdx.game;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

import cards.*;

public class Match {

	Player p1;
	Player p2;
	APMeter p1m;

	boolean cardDraw;
	boolean turnOver;
	boolean textDisplay;
	int turnCount;
	SpriteBatch batch;
	BitmapFont font;
	//SpriteBatch HP;
	int screenHeight = 720;
	int screenWidth = 1280;
	Actor textBox;
	int maxAP=40;

	public Stage stage;
	
	TurnDisplay tDisplay;
	//LargeDisplay large;

	public Match(SpriteBatch batch, Stage stage) {

		tDisplay = new TurnDisplay();
		
		p1 = new PlayerLocal("Player 1", stage);
		p2 = new PlayerCPU("CPU");
		this.stage = stage;
		this.batch = batch;
		font= new BitmapFont();
		font.setColor(0,0,0,255);
		//HP = new SpriteBatch();
		
		
		cardDraw = true;
		turnCount = 0;
		turnOver = false;

		/*this.font = new BitmapFont();
		this.font.setColor(0, 0, 0, 255);*/
		
		// /////////CREATE DECKS -- TEST--/////

		// Creates two decks, one for each player. for the hack only
		for (int i = 0; i < p1.deck.deckSize; i++) {
			Card card;
			Random r = new Random();
			int x = r.nextInt(5);
			if (x == 0) {
				card = new CardBear(p1, stage);
				// p1.deck.addCard(card);
			} else if (x == 1) {
				card = new CardLion(p1,stage);
				// p1.deck.addCard(card);
			} else if (x == 2) {
				card = new CardDragon(p1,stage);
				// p1.deck.addCard(card);
			} else if (x == 3) {
				card = new CardPepe(p1,stage);
				// p1.deck.addCard(card);
			} else if (x == 4) {
				card = new CardEuthanise(p1);
			} else {
				card = new Card(p1);
			}
			p1.deck.addCard(card);
			card.setX(1280-140);
			card.setY(0);
			card.setPosition(card.getX(), card.getY());
			card.positionChanged();

			stage.addActor(p1.deck.deck.peek());
		}

		for (int i = 0; i < p2.deck.deckSize; i++) {
			Card card;
			Random r = new Random();
			int x = r.nextInt(4);
			if (x == 0) {
				card = new CardBear(p2,stage);
				// p1.deck.addCard(card);
			} else if (x == 1) {
				card = new CardLion(p2,stage);
				// p1.deck.addCard(card);
			} else if (x == 2) {
				card = new CardDragon(p2,stage);
				// p1.deck.addCard(card);
			} else if (x == 3) {
				card = new CardPepe(p2,stage);
				// p1.deck.addCard(card);
			} else {
				card = new Card(p2);
			}
			
			//card.setPosition(1280 - 140, 720 - 180);
			//card.setOrigin(card.getWidth()/2, card.getHeight()/2);
			card.rotateCard();
			card.setX(1280-140);
			card.setY(720-180);
			card.setPosition(card.getX(), card.getY());
			card.positionChanged();
			
			p2.deck.addCard(card);
			
			stage.addActor(p2.deck.deck.peek());
			
			
		}

		// /////
		// match = new Match(p1, p2);

		
		p1.initialisePlayer(stage);
		p2.initialisePlayer(stage);
		
		stage.addActor(tDisplay);
		
	}
	public void act(){
		font.draw(batch, "HEUEHE",0, 500);
		stage.draw();
		//displayCards(p1, 180, 0);
		//displayCards(p2, 360, 540);
		
		if (cardDraw == true && turnCount % 2 == 0){
			tDisplay.scroll(tDisplay.player1Texture());
			cardDraw = p1.drawFromDeck();
		}
			
			
			
		if (turnCount % 2 == 0) {
			turnOver = p1.takeTurn(p2);
		}
		// if 2
		if (cardDraw == true && turnCount % 2 == 1){
			tDisplay.scroll(tDisplay.player2Texture());
			cardDraw = p2.drawFromDeck();
		}
			
		if (turnCount % 2 == 1) {
			turnOver = p2.takeTurn(p1);
		}
		
		if (turnOver == true) {

			turnOver = false;
			cardDraw = true;
			turnCount++;
		}
		
		if (p1.hasWon(p2)) {
			font.draw(batch, "Player 1 Wins", 0, 350);
		}
		
		if (p2.hasWon(p1)) {
			font.draw(batch, "Player 2 Wins", 0, 350);
		}
		
		font.draw(batch, p1.selectedItem +" "+ p1.selectedActor, 0, 300);
		font.draw(batch, p1.AP+"",0, 450);
		
	}

}
