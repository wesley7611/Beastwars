/**
* PlayerCPU is an extension of the player class, which will handle the player turn as an AI
* opponent.
* 
*
* @author  Philip Wesley
* @version 1.0
* @since   2016-11-25 
*/package com.mygdx.game;

import java.util.Random;

//CPU player - For hack, will play first 4 cards from hand and randomly choose one to attack its opposite opponent
public class PlayerCPU extends Player  {

	public PlayerCPU(String name) {
		super(name);
		
	}
	public boolean takeTurn(Player enemy){
		while(!field.isFieldFull()){
			if(field.getFieldSize()<4)
			{
				playFromHand(0);
			}
		}
		Random r = new Random();
		int x = r.nextInt(4);
		int y = r.nextInt(enemy.field.getFieldSize());
		if(field.returnCard(x)!=null  && field.returnCard(x).isDefeated()==false && enemy.field.returnCard(y).isDefeated()==false){
			field.returnCard(x).attack(enemy.field.returnCard(y));
			replenishAP();
			return true;
		}
		return false;
	}

}
