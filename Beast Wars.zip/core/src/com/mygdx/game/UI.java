package com.mygdx.game;

public class UI {

	public UI() {
		// TODO Auto-generated constructor stub
	}

}
