package cards;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.mygdx.game.Player;

public class CardDragon extends ActorCard{
	Card dragon;
	public CardDragon(Player owner, Stage stage){
		super(owner, stage);
		dragon = new Card(owner);
		setMaxHP(100);
		currentHP=getMaxHP();
		name = "Dragon";
		attackCost = 6;
		upkeep=5;
		front = new Texture(Gdx.files.internal("cardDragon.jpg"));
		//sprite = new Sprite(back);
		//type = 1;
		createHealthDisplay(10);
	}
	public int attack(ActorCard target){
		target.decreaseHP(60);
		return attackCost;
	}

}